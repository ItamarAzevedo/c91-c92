import React, {Component} from "react";
import {Text, View, StyleSheet,StatusBar,SafeAreaView,Platform,TouchableOpacity,Image,ImageBackground} from "react-native"

export default class Home extends Component{
  render(){
    return(
      <View style={styles.container}>
      <SafeAreaView style={styles.droidSafeArea}/>
      <ImageBackground
      source={require("../assets/tela_de_inicio.png")}
      style={styles.backgroundImage}>
      <View style={styles.titleBar}>
      <Text style={styles.text}>Planejamento Saudavel</Text>
      </View>

      <TouchableOpacity style={styles.routeCard}
      onPress={()=>this.props.navigation.navigate("Profile")}>
      <Text style={styles.routeText1}>Perfil</Text>
      <Image
      source={require("../assets/profile_1.png")}
      style={styles.iconImage1}>
      </Image>
      </TouchableOpacity>

      <TouchableOpacity style={styles.routeCard}
      onPress={()=>this.props.navigation.navigate("Food")}>
      <Text style={styles.routeText2}>Alimentação</Text>
      <Image
      source={require("../assets/food_2.jpg")}
      style={styles.iconImage2}>
      </Image>
      </TouchableOpacity>

      <TouchableOpacity style={styles.routeCard}
      onPress={()=>this.props.navigation.navigate("Exercise")}>
      <Text style={styles.routeText3}>Exercícios</Text>
      <Image
      source={require("../assets/exercicios.jpg")}
      style={styles.iconImage3}>
      </Image>
      </TouchableOpacity>
      </ImageBackground>
      </View>
    )
  }
}

const styles=StyleSheet.create({
  container:{
    flex:1,
  },
  droidSafeArea:{
    marginTop:Platform.OS==="android"?StatusBar.currentHeight:0,
  },
  text:{
    color:"blue",
    fontSize:28,
    fontFamily:"bold",
    alignItems:"center",
    justifyContent:"center",
    marginLeft:15
  },
  titleBar:{
    flex:0.25,
    alignItems:"center",
    justifyContent:"center",
  },
  routeCard:{
    flex:0.25,
    marginLeft:50,
    marginRight:50,
    marginTop:100,
    borderRadius:30,
    backgroundColor:"cyan",
    borderWidth:5
  },
  routeText1:{
    fontSize:25,
    fontWeight:"bold",
    color:"#7134eb",
    marginTop:20,
    marginLeft:11,
    justifyContent:"center",
  },
  routeText2:{
    fontSize:22,
    fontWeight:"bold",
    color:"#7134eb",
    marginTop:20,
    marginLeft:5
  },
  routeText3:{
    fontSize:25,
    fontWeight:"bold",
    color:"#7134eb",
    marginTop:20,
    marginLeft:5
  },
  digit:{
    position:"absolute",
    color:"#7134eb",
    fontSize:130,
    right:0,
    bottom:-15,
    zIndex:-1
  },
  backgroundImage:{
    flex:1,
    resizeMode:"cover",
    height:570,
    width:310
  },
  iconImage1:{
    position:"absolute",
    height:50,
    width:280,
    resizeMode:"contain",
    right:40,
    top:5,
    left:20,
    opacity:0.5
  },
   iconImage2:{
    position:"absolute",
    height:50,
    width:280,
    resizeMode:"contain",
    right:40,
    top:5,
    left:20,
    opacity:0.5
  },
   iconImage3:{
    position:"absolute",
    height:50,
    width:280,
    resizeMode:"contain",
    right:40,
    top:5,
    left:20,
    opacity:0.5
  }
})